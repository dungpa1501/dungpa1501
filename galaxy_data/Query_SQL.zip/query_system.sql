-- Check space used log file
DBCC SQLPERF(LOGSPACE);